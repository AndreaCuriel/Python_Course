def potencia(base, exponente):
	print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
	print("el resultado de redondear es: " , round(numero))



	